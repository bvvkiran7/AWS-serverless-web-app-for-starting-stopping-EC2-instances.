
export const ENDPOINT_NAME = "ec2-controller-endpoint";
